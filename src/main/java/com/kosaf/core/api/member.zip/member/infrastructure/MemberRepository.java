package com.example.core.api.member.infrastructure;

// JPA 사용시 Repository
// @Repository
public interface MemberRepository /* extends JpaRepository<Member, Long> */ {

}
