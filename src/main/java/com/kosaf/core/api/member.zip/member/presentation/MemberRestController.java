package com.example.core.api.member.presentation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.core.api.member.application.MemberService;
import com.example.core.api.member.application.dto.MemberCreateDTO;
import com.example.core.api.member.application.dto.MemberDTO;
import com.example.core.api.member.application.dto.MemberDetailDTO;
import com.example.core.api.member.application.dto.MemberListParam;
import com.example.core.api.member.application.dto.MemberUpdateDTO;
import com.example.core.common.ApiResponse;
import com.example.core.common.PageResult;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class MemberRestController {

  // RestAPI Controller

  private final MemberService memberService;
  private static final Logger log = LoggerFactory.getLogger(MemberRestController.class);

  @GetMapping("/members")
  public ApiResponse<PageResult<MemberDTO>> findAll(@RequestBody MemberListParam param) {

    return memberService.findAll(param);
  }

  @GetMapping("/member/{memberNo}")
  public ApiResponse<MemberDetailDTO> findById(@PathVariable Long memberNo) {

    return memberService.findById(memberNo);
  }

  @PostMapping("/member")
  public ApiResponse<Long> create(@RequestBody MemberCreateDTO createDTO) {

    return memberService.create(createDTO);
  }

  @PatchMapping("/member")
  public ApiResponse<MemberDetailDTO> update(@RequestBody MemberUpdateDTO updateDTO) {

    return memberService.update(updateDTO);
  }

  @DeleteMapping("/member/{memberNo}")
  public ApiResponse<Void> delete(@PathVariable Long memberNo) {

    return memberService.delete(memberNo);
  }

}
