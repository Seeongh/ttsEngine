package com.example.core.api.member.application.dto;

import java.time.LocalDateTime;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import com.example.core.api.member.domain.Member;
import com.example.core.api.member.value.Gender;
import com.example.core.api.member.value.MemberStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberUpdateDTO {

  // Member Update를 위한 DTO

  private Long memberNo;
  private String memberName;

  @Enumerated(EnumType.STRING)
  private Gender gender;

  private String mobile;
  private String address;

  @Enumerated(EnumType.STRING)
  private MemberStatus memberStatus;

  private LocalDateTime regDt;

  public Member toEntity() {
    return Member
        .builder()
        .memberNo(memberNo)
        .memberName(memberName)
        .gender(gender)
        .mobile(mobile)
        .address(address)
        .build();
  }
}
